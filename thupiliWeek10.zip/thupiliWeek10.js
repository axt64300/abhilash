//created by thupili
//id:700656430

//event listener for page load:
window.addEventListener("load",function(){
	fillStates();  //fills the states for the options
	
	//event listener for the dropdown change event
document.getElementById("stateDropdown").addEventListener("change",function(){
	//pass the state selected, and call a funciton to much the state selected for its capital city.
	
	var selectedIndex = document.getElementById("stateDropdown").selectedIndex;
	//gets the index of the state selected by the user;
	
	var selectedState = document.getElementById("stateDropdown").options[selectedIndex].value;
	//gets the index of the state selected for the options list.
	
	//call a function to raise xhr and compare the state name to get its capital.
	
	findCapital(selectedState);
	
},false);//end event listener for select.

//event listener for textButton:

		var xhr= new XMLHttpRequest(); //xhr instantiated
		//create event listener
		xhr.addEventListener("readystatechange",function(){
			
			if(xhr.readyState == 4 && xhr.status == 200 && xhr.responseXML){
				//we have the xml file
				var statesArray = xhr.responseXML.getElementsByTagName("state");
				//this is a nodelist of state tags
				var selectTag = document.getElementById("stateDropdown");
				
				//loop through
				for(var i = 0;i< statesArray.length; i++){
					var stateName = statesArray.item(i).getElementsByTagName("name").item(0).firstChild.nodeValue;
					//gets the name of one state
					
					//create option element
			        var optionTag = document.createElement("option");
					optionTag.value= stateName;
					optionTag.innerHTML = stateName;
					//append option tag to select tag;
					selectTag.appendChild(optionTag);
				}//end for 
				
			}//end if
			
		},false); //event listener for readystatechange event.
		
		xhr.open("get","thupiliweek10states.xml",true); //request open
		xhr.send(null);
}catch (exception){
	//xhr failed:
	alert("XHR Failed");
}//end try catch
}//end funciton fill states


   function findCapital(selectedState){
	   //raise xhr,create readyState eventlistener,then from the xml file---loop through and compare the state to selected state and its sibling
	   //element will be the capital.
	   try {
		   var xhr = new XMLHttpRequest();//xhr instantiated
		   //create eventlistener:
		   xhr.addEventListener("readystatechange",function(){
			   
			    if(xhr.readyState == 4 && xhr.status == 200 && xhr.responseXML){
					var statesArray = xhr.responseXML.getElementsByTagName("state");
					//this is a node list of state tags.
					
					//loop through
					for(var i = 0;i < statesArray.length;i++){
						stateName = statesArray.item(i).getElementsByTagName("name").item(0).firstChild.nodeValue;
						//compare if the state name is the same as selected:
						if(selectedState == stateName){
							var capital = statesArray.item(i).getElementsByTagName("capital").item(0).firstChild.nodeValue;
							
							//dispaly the result
							
							document.getElementById("capitalLabel").innerHTML = capital;
							//match found . so exit the funciton;
							return;
							
						}//end if
					}//end for 
					
				}//end if
		   },false);//event listener for readystatechange event.
		   
		   xhr.open("get","thupiliweek10states.xml",true); //request open
		   xhr.send(null);
		   
	   }catch (exception){
		   //xhr failed:
		   alert("XHR Failed");
	   }// end try catch
	   
   }//end fucntion findCapital
   
   function getTextfile(){
	   //raise xhr;
	   var xhr = new XMLHttpRequest();
	   //read state event:
	   
	   xhr.onreadystatechange = function(){
		   if (xhr.readyState==4 && xhr.status == 200 && xhr.responseText {
			   //dispaly the text
			   document.getElementById("textDiv").innerHTML = xhr.responseText
			   
		   }//end if
	   }//edn funciton
	   xhr.open("get","AboutAjax.txt",true);
	   xhr.send(null);
   }